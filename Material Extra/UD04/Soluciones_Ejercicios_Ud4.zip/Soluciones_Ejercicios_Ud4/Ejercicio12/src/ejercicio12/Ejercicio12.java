/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio12;

import java.io.*;
/**
 *
 * Ejercicio 12: Programa que lee un número y me dice si es 
 *               positivo o negativo, consideraremos el cero como positivo. 
 */
public class Ejercicio12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
        int numero;

        System.out.print("Introduce un número: ");
        numero = Integer.parseInt(stdin.readLine()); 
        
        if(numero >= 0)
            System.out.println("El número es positivo");
        else
            System.out.println("El número es negativo");
    }
    
}
