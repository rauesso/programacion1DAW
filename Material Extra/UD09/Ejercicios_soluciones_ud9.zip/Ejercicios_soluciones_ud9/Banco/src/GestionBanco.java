/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

public class GestionBanco {

    public static void main(String arg[]){
        
    CuentaCorriente cC1 = new CuentaCorriente("0001",2000);
    CuentaAhorro cA1 = new CuentaAhorro("0001",1000);

    cC1.mostrar();
    cA1.mostrar();

    cC1.ingresar(2000);
    cA1.retirar(500);
    cC1.mostrar();
    cA1.mostrar();

    cC1.traspaso(cA1, 200);
    cC1.mostrar();
    cA1.mostrar();

    cC1.calcularIntereses();
    cA1.calcularIntereses();
    cC1.mostrar();
    cA1.mostrar();
    }
}
