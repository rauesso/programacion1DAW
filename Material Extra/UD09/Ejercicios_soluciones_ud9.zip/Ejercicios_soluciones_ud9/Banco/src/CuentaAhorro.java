/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


public class CuentaAhorro extends CuentaBancaria{
    final float saldoMinimo=3000f;

    public CuentaAhorro(String num,float sald){
        super(num,sald);
    }

    @Override
    public void calcularIntereses(){
        float interes;

        if(this.getSaldo()<saldoMinimo)
            interes=super.getSaldo()*((interesAnualBasico/2)/100); //anteponemos super. al método getSaldo() para remarcar que se trata de un método heredado, pero funcionaría igualmente si no lo pusiéramos
           else
            interes=super.getSaldo()*((interesAnualBasico*2)/100);
        super.ingresar(interes);
    }
    
    
    @Override
    public void mostrar(){

        System.out.println("Numero de cuenta ahorro :"+this.getNumCuenta());
        System.out.println("Saldo                   :"+this.getSaldo());
        System.out.println();

    }
}
