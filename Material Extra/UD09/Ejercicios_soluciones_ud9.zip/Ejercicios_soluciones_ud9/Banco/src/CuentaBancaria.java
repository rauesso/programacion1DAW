/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

abstract public class CuentaBancaria {
    private String numCuenta;
    private float  saldo;
    final float interesAnualBasico=2.5f;

    public CuentaBancaria(String numero,float saldo){
        this.numCuenta = numero;
        this.saldo = saldo;
    }

    abstract void calcularIntereses();
    public abstract void mostrar();

    public String getNumCuenta() {
        return numCuenta;
    }

    public void setNumCuenta(String numCuenta) {
        this.numCuenta = numCuenta;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    private void añadir(float cantidad) {
        this.saldo += cantidad;
    }

    public void ingresar(float cant) {
        añadir(cant);
    }
    
    public void retirar(float cant) {
        añadir(-cant);
    }

    public void traspaso(CuentaBancaria cc, float cant) {
        this.añadir(cant);
        cc.añadir(-cant);
    }
    
}
