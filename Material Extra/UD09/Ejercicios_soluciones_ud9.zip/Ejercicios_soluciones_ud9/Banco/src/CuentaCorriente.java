/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

public class CuentaCorriente extends CuentaBancaria{

    public CuentaCorriente(String num,float sald){
        super(num,sald);
    }

    @Override
    public void calcularIntereses(){
        float interes;

        interes=super.getSaldo()*(interesAnualBasico/100);
        super.ingresar(interes);
    }
    
    @Override
    public void mostrar(){
        System.out.println("Numero de cuenta corriente: "+this.getNumCuenta());
        System.out.println("Saldo: "+this.getSaldo());
        System.out.println();
    }

}
