/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Planetas extends Astros{
    private double distSol;
    private double orbSol;
    private int numSat;
    
    Planetas(String nom, double a, double b, double c, float f1, float f2, double d, double e, int g){
        super(nom,a,b,c,f1,f2);
        this.distSol = d;
        this.orbSol  = e;
        this.numSat = g;
    }

    public void muestra() {
        //no sacamos todos los atributos por simplificar...
        System.out.println("Nombre :"+this.getNombre());
        System.out.println("Radio  :"+this.getRadio());
        System.out.println("Dist al sol :"+this.distSol);
        System.out.println("Órbita al sol :"+this.orbSol);
        System.out.println("Número de satélites :"+this.numSat);
    }
}
