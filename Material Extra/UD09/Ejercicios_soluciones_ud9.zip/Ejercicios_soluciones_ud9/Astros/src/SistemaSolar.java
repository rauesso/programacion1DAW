
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

public class SistemaSolar {
    public static void main(String args[]) throws IOException{
        BufferedReader entrada_general = new BufferedReader(new InputStreamReader(System.in));
        String buscar;
        boolean encontrado;

        // En este ejemplo creamos una lista, insertamos dos astros y realizamos una búsqueda.
        ArrayList astros = new ArrayList();

        Planetas  pla1 = new Planetas("Tierra",5.0,3.0,4.0,3.0f,5.0f,6.0,7.0,1);
        Satelites sat1 = new Satelites("Luna", 5.0,3.0,4.0,3.0f,5.0f,6.0,7.0,"Tierra");
        Astros astro;

        astros.add(pla1);
        astros.add(sat1);

        System.out.print("Astro a buscar: ");
        buscar = entrada_general.readLine();
        encontrado = false;

        for( Iterator it2 = astros.iterator(); it2.hasNext();) {
            astro = (Astros) it2.next();
            if (astro.getNombre().equalsIgnoreCase(buscar)) {
                astro.muestra(); // Interesante ver como usando una variable de la clase Astro se puede llamar al método "muestra" de las clases hijas.
                encontrado = true;
            }
        }
        
        if (!encontrado)
            System.out.println("Astro no encontrado.");
    }
}
