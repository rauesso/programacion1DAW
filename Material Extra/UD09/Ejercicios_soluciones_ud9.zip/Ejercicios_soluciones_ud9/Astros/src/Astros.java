/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

// Clase abstracta 
abstract class Astros {
    private String nombre;
    private double radio;
    private double rotEje;
    private double masa;
    private float tempMedia;
    private float gravedad;

    public Astros(String nom, double a, double b, double c, float f1, float f2){
        this.nombre = nom;
        this.radio  = a;
        this.rotEje = b;
        this.masa   = c;
        this.tempMedia = f1;
        this.gravedad  = f2;
    }

    // Método abstracto. Debe implementarse en todas las clases hijas.
    abstract public void muestra();

    public double getRadio() {
        return radio;
    }

    public void setRadio(double radio) {
        this.radio = radio;
    }

    public double getRotEje() {
        return rotEje;
    }

    public void setRotEje(double rotEje) {
        this.rotEje = rotEje;
    }

    public double getMasa() {
        return masa;
    }

    public void setMasa(double masa) {
        this.masa = masa;
    }

    public float getTempMedia() {
        return tempMedia;
    }

    public void setTempMedia(float tempMedia) {
        this.tempMedia = tempMedia;
    }

    public float getGravedad() {
        return gravedad;
    }

    public void setGravedad(float gravedad) {
        this.gravedad = gravedad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

}
