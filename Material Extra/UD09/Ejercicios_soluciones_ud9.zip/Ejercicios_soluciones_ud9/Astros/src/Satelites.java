/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Satelites extends Astros{
    private double distPlaneta;
    private double orbPlaneta;
    private String nomPlaneta;

    Satelites(String nom,double a, double b, double c, float f1, float f2, double d, double e, String nom2){
        super(nom,a,b,c,f1,f2);
        this.distPlaneta = d;
        this.orbPlaneta  = e;
        this.nomPlaneta =nom2;
    }

    public void muestra() {
        //no sacamos todos los atributos por simplificar...
        System.out.println("Nombre :"+this.getNombre());
        System.out.println("Radio  :"+this.getRadio());
        System.out.println("Dist al planeta :"+this.distPlaneta);
    }
}