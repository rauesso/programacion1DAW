/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

public class Producto {
    private String nombre;
    private int cantidad;

    public Producto(String nom, int cant){
        this.nombre = nom;
        this.cantidad = cant;
    }
    public Producto(){
        this.nombre = null;
        this.cantidad = 0;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

}
