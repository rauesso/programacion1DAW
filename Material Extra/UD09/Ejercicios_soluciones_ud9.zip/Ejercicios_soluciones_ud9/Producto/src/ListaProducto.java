/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class ListaProducto {
    public static void main(String args[]) throws IOException{

// Definimos una lista de Productos.
    ArrayList <Producto> lista = new ArrayList <Producto>();
    
// ALTERNATIVA: Definimos de la forma tradicional 5 instancias de la Clase Producto
   
//    Producto m = new Producto("Pan", 6);
//    Producto n = new Producto("Leche", 2);
//    Producto o = new Producto("Manzanas", 5);
//    Producto p = new Producto("Brocoli", 2);
//    Producto q = new Producto("Carne", 2);

// Añadimos los objetos a la lista de la forma tradicional (uno a uno)
//    lista.add(m);
//    lista.add(n);
//    lista.add(o);
//    lista.add(p);
//
// Indica el indice de inserción
//    lista.add(1, q);
//    lista.add(q);

    
// ALTERNATIVA: Añadimos los objetos a la lista con un bucle. 
    for (int i=0; i<5;i++) {
        Producto m = new Producto(); //es necesario instanciar la clase para q reserve una nueva dirección de memoria en cada iteración del bucle y no machaque siempre la info del objeto m
        lista.add (m);
    }
    
    //Rellenamos con datos cada objeto de la lista   
    for (int i=0; i<lista.size();i++) {           
        rellenaProducto(lista.get(i));
    }
    
    
    // Imprimir contenido de ArrayLists
    System.out.println(" - Lista de productos con " + lista.size() + " elementos");

    // Definir Iterator para extraer/imprimir valores
    for( Iterator it = lista.iterator(); it.hasNext(); ) {
        Producto x = (Producto)it.next();
        System.out.println(x.getNombre() + " : " + x.getCantidad());
    }

    // Eliminar elemento de ArrayList
    lista.remove(2);
    System.out.println(" - Lista de productos con " + lista.size() + " elementos");

    // Definir Iterator para extraer/imprimir valores
    for( Iterator it2 = lista.iterator(); it2.hasNext();) {
    Producto x = (Producto)it2.next();
    System.out.println(x.getNombre() + " : " + x.getCantidad());
    }

    // Eliminar todos los valores del ArrayList
    lista.clear();
    System.out.println(" - Lista de productos final con " + lista.size() + " elementos");
}
    //Función rellenaProducto
    public static void rellenaProducto(Producto p) throws IOException{
        BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.println(" Introduce un nombre de producto: ");
        p.setNombre(stdin.readLine());
        
        System.out.println(" Introduce cantidad del producto "+ p.getNombre()+": ");
        p.setCantidad(Integer.parseInt(stdin.readLine()));
    }
}