/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio6;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * Ejercicio 6: Programa que pide el DNI y devuelve la letra asociada.
 * 
 */
public class Ejercicio6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in));
        int dni;
        char nif;
        
        System.out.print("Introduce el dni(8 dígitos): ");
        dni = Integer.parseInt(entrada.readLine()); // No comprobamos que hay 8 dígitos. Te lo dejamos a ti ;)
        
        nif = calcularNif(dni);
        
        System.out.println("El NIF para el número " + dni + " es " + nif);
    }
    
    /**
     * 
     * Función que devuelve la letra del dni
     * Entrada: número entero (dni)
     * Valor devuelto: carácter (nif)
     */
    public static char calcularNif(int dni)
    {
        char nif = ' ';
        
        switch(dni % 23)
        {
            case 0:
                nif = 'T';
            break;
            case 1:
                nif = 'R';
            break;
            case 2:
                nif = 'W';
            break;
            case 3:
                nif = 'A';
            break;
            case 4:
                nif = 'G';
            break;
            case 5:
                nif = 'M';
            break;
            case 6:
                nif = 'Y';
            break;
            case 7:
                nif = 'F';
            break;
            case 8:
                nif = 'P';
            break;
            case 9:
                nif = 'D';
            break;
            case 10:
                nif = 'X';
            break;
            case 11:
                nif = 'B';
            break;
            case 12:
                nif = 'N';
            break;
            case 13:
                nif = 'J';
            break;
            case 14:
                nif = 'Z';
            break;
            case 15:
                nif = 'S';
            break;
            case 16:
                nif = 'Q';
            break;
            case 17:
                nif = 'V';
            break;
            case 18:
                nif = 'H';
            break;
            case 19:
                nif = 'L';
            break;
            case 20:
                nif = 'C';
            break;
            case 21:
                nif = 'K';
            break;
            case 22:
                nif = 'E';
            break;
        }
        
        return nif;
    }
}
