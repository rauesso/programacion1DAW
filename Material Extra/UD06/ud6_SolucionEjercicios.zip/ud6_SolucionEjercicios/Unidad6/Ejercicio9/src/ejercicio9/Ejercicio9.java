/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio9;

import java.util.Scanner;

/**
 *
 * Ejercicio 9: Programa que realiza la multiplicación de dos números 
 *              enteros positivos introducidos por teclado utilizando 
 *              solamente el operador suma. (Función recursiva)
 */
public class Ejercicio9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int num1, num2, mult;
        
        System.out.print("Introduce el primer número: ");
        num1 = in.nextInt();
        
        System.out.print("Introduce el segundo número: ");
        num2 = in.nextInt();
        
        mult = multiplicacion(num1, num2);
        
        System.out.println("La multiplicación es " + mult);
    }
    
    /**
     * 
     * Función que devuelve la multiplicación de dos números enteros usando sólo
     * el operador suma. (Función recursiva)
     * Entrada: número entero (n1)
     *          número entero (n2)
     * Valor devuelto: entero (mult)
     */
    public static int multiplicacion(int n1, int n2)
    {
        int mult;
        
        if(n2 == 1)
            mult = n1;
        else
            mult = n1 + multiplicacion(n1, n2-1);
        
        
        return mult;
        
    }    
}
