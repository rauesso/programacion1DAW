/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio8;

/**
 *
 * Ejercicio 8: Programa que escribe las tabla de multiplicar del 1 al 10 
 */
public class Ejercicio8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        muestraTablas();
    }
    
    /**
     * 
     * Función que muestra las tablas de multiplicar del 1 al 10.
     * Entrada: ninguna
     * Valor devuelto: ninguno
     */
    public static void muestraTablas()
    {

        int i, j, mult = 0;
        
        for(i = 1; i <= 10; i++)
        {
            System.out.println("Tabla del " + i);
            
            for(j = 0; j <= 10; j++)
            {
                mult = i * j;
                System.out.println(i + " * " + j + " = " + mult);
            }
        }
    }
}
