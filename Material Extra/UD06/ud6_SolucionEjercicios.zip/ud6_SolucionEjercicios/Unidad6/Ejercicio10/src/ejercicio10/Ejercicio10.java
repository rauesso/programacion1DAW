/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio10;

import java.util.Scanner;

/**
 *
 * Ejercicio 10: Programa que dado un número entero positivo devuelve la suma 
 *               de sus dígitos. (Función recursiva)
 */
public class Ejercicio10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int num, suma;
        
        System.out.print("Introduce el número: ");
        num = in.nextInt();
        
        suma = sumaDigitos(num);
        
        System.out.println("La suma de los dígitos es " + suma);
    }
    
    /**
     * 
     * Función que devuelve la suma de los dígitos del número pasado 
     * por parámetro (Función recursiva)
     * Entrada: número entero (num)
     * Valor devuelto: entero (suma)
     */
    public static int sumaDigitos(int num)
    {
        int suma;
        
        if(num < 10)
            suma = num;
        else
            suma = (num % 10) + sumaDigitos (num / 10) ;
        return suma;
        
    }
}
