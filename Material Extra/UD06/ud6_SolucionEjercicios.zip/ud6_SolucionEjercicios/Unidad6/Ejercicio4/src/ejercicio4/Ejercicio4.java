/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * Ejercicio 4: Programa que lee una fecha introduciendo 
 *             el día, el mes y el año por separado y nos diga 
 *             si la fecha es correcta o no.
 */
public class Ejercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in));
        int dia, mes, año;
        
        System.out.print("Introduce el día: ");
        dia = Integer.parseInt(entrada.readLine());
        
        System.out.print("Introduce el mes: ");
        mes = Integer.parseInt(entrada.readLine());
        
        System.out.print("Introduce el año: ");
        año = Integer.parseInt(entrada.readLine());
        
        if(comprobarFecha(dia, mes, año) == true) // Se realiza la llamada a la función y se compara el resultado
            System.out.println("La fecha es correcta.");
        else
            System.out.println("La fecha es incorrecta.");
    }
    
    /**
     * 
     * Función que determina si una fecha es correcta o no
     * Entrada: número entero (dia)
     *          número entero (mes)
     *          número entero (año)
     * Valor devuelto: booleano (fecha_correcta)
     */
    public static boolean comprobarFecha (int dia, int mes, int año)
    {
        boolean fecha_correcta = true;
        
        // Comprobamos que el día esté entre 1 y 31, el mes entre 1 y 12 y el año entre 1 y 9999 (por ejemplo)
        if((dia < 1 || dia > 31) || (mes < 1 || mes > 12) || (año < 1 || año > 9999))
            fecha_correcta = false;
        else
        {
            // Los valores están bien introducidos, ahora vamos a comprobar si el día y mes son correctos
            
            switch(mes)
            {
                case 2: // Febrero
                    if(dia > 28) // No realizamos la comprobación de si el año es bisiesto. Anímate a hacerlo!
                        fecha_correcta = false;
                break;
                case 4: // Abril, junio, septiembre y noviembre tienen 30 días. El resto de meses no hace falta comprobarlos ya que 'dia' como máximo va a ser 31.
                case 6:
                case 9:
                case 11:
                    if(dia > 30)
                        fecha_correcta = false;
                break;
            }
        }
        return fecha_correcta;
    }
}
