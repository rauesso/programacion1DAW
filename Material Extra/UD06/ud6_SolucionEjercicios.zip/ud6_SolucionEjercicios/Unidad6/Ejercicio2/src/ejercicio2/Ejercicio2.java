/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * Ejercicio 2: Programa que dado un valor en millas lo pasa a metros.
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in));
        double millas;
        
        System.out.print("Introduce el número de millas: ");
        millas = Double.parseDouble(entrada.readLine());
        
        // Podemos llamar a la función dentro del System.out y mostrar la salida
        System.out.println("El número de metros es " + millasAMetros(millas)); 
        
    }
    
    /**
     * 
     * Función que pasa de millas a metros.
     * Entrada: un número real (millas)
     * Valor devuelto: un número real (metros)
     */
    public static double millasAMetros(double millas)
    {

        double metros;
        
        metros = millas * 1609.344;

        return metros;
    }

}
