/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1;

import java.util.Scanner;

/**
 *
 * Ejercicio 1: Programa que escribe la tabla de multiplicar 
 *              de un número entero introducid por teclado
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int num;
        
        System.out.print("Introduce un número entero: ");
        num = entrada.nextInt();
        
        muestraTabla(num); // Lamada a la función 
    }
    
    /**
     * 
     * Función que muestra la tabla de multiplicar de un número.
     * Entrada: un número entero (n)
     * Valor devuelto: ninguno
     */
    public static void muestraTabla(int n)
    {

        int i, mult = 0;
        
        for(i = 0; i <= 10; i++)
        {
            mult = n * i;
            System.out.println(n + " * " + i + " = " + mult);
        }
    }
    
}
