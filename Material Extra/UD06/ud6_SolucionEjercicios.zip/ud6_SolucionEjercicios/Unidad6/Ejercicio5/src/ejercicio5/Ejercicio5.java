/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio5;

import java.util.Scanner;

/**
 *
 * Ejercicio 5: Programa que nos pida número enteros hasta 
 *             que se introduzca el 0, diciéndonos, para cada 
 *             número introducido si es primo o no.
 */
public class Ejercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int num;
        
        System.out.print("Introduce un número entero (0 para acabar): ");
        num = entrada.nextInt();
        
        while(num != 0)
        {   
            if(esPrimo(num)) // Equivalente a (esPrimo(num) == true) y '!esPrimo(num)' es quivalente a (esPrimo(num) == false)
            {
                System.out.println("El número es primo.");
            }
            else
                System.out.println("El número no es primo.");
            
            System.out.print("Introduce otro número entero (0 para acabar): ");
            num = entrada.nextInt();
        }
    }
    
    /**
     * 
     * Función que determina si un número es primo o no
     * Entrada: número entero (num)
     * Valor devuelto: booleano (primo)
     */
    public static boolean esPrimo(int num) 
    {
        boolean primo = true;
        int cont;

        for (cont = 2; cont <= (num / 2) && primo == true; cont++)
        {
            if (num % cont == 0)
            {
               primo = false;
            }
        }
        return(primo);
    }

}
