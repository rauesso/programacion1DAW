/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio7;

import java.util.Scanner;

/**
 *
 * Ejercicio 7: Programa que comprueba si una terna determinada 
 *             de valores enteros se ajusta a la ecuación de Pitágoras.
 * 
 */
public class Ejercicio7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int x, y, z;
        boolean pitagoras;
        
        System.out.print("Introduce la x: ");
        x = entrada.nextInt();
        
        System.out.print("Introduce la y: ");
        y = entrada.nextInt();
        
        System.out.print("Introduce la z: ");
        z = entrada.nextInt();
        
        pitagoras = comprobarPitagoras(x, y, z);
        
        if(pitagoras)
            System.out.println("La ecuacion de pitágoras se cumple.");
        else
            System.out.println("La ecuacion de pitágoras no se cumple.");
    }
    
    /**
     * 
     * Función que comprueba si se cumple la ecuación de Pitágoras
     * Entrada: número entero (x)
     *          número entero (y)
     *          número entero (z)
     * Valor devuelto: booleano (iguales)
     */
    public static boolean comprobarPitagoras(int x, int y, int z)
    {
        boolean iguales = false;
        
        if((Math.pow(x, 2) + Math.pow(y, 2)) == Math.pow(z, 2))
            iguales = true;
        
        return iguales;
    }
}
