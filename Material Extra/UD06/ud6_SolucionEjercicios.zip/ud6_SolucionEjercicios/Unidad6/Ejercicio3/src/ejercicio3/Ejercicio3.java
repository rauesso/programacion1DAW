/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio3;

import java.util.Scanner;

/**
 *
 * Ejercicio 3: Programa que calcula el porcentaje de descuento que 
 *              nos han hecho al comprar algo.
 */
public class Ejercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        double cant_sin_desc, cant_con_desc, descuento;
        
        do
        {
            System.out.print("Introduce la cantidad sin el descuento: ");
            cant_sin_desc = entrada.nextDouble();

            // Comprobamos que la cantidad sin el descuento sea positiva
            while(cant_sin_desc < 0)
            {
                System.out.println("Error. La cantidad debe ser positiva.");
                System.out.print("Introduce la cantidad sin el descuento: ");
                cant_sin_desc = entrada.nextDouble();
            }

            System.out.print("Introduce la cantidad con el descuento: ");
            cant_con_desc = entrada.nextDouble();

            // Comprobamos que la cantidad con el descuento sea positiva
            while(cant_con_desc < 0)
            {
                System.out.println("Error. La cantidad debe ser positiva.");
                System.out.print("Introduce la cantidad con el descuento: ");
                cant_con_desc = entrada.nextDouble();
            }  
            
            // Comprobamos que la cantidad sin descuento sea mayor que la cantidad con descuento
            if(cant_sin_desc < cant_con_desc)
                System.out.println("Error. La cantidad con descuento no puede ser mayor a la cantidad sin descuento.");
            
        }while(cant_sin_desc < cant_con_desc); // si el 'if' se cumple volvemos a pedir los datos
        
        descuento = calcularDescuento(cant_sin_desc, cant_con_desc);
        
        System.out.println("El descuento realizado es del " + descuento + "%");
    }
    
    /**
     * 
     * Función que calcula el descuento realizado
     * Entrada: número real (cantSinDesc)
     *          número real (cantConDesc)
     * Valor devuelto: un número real (descuento)
     */
    public static double calcularDescuento (double cantSinDesc, double cantConDesc)
    {
        double descuento;
        
        // Realizamos el redondeo del descuento.
        descuento = Math.round(100 * (1 - (cantConDesc / cantSinDesc)));
        
        return descuento;
    }

}
