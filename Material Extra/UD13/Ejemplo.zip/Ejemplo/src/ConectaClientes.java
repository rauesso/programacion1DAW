

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class ConectaClientes {
    
    // Declaramos los atributos
    Connection conn; // Para crear la conexión de la base de datos
    Statement sentenciaSQL; // Para realizar las operaciones SQL
    ResultSet rs; // Para almacenar los datos devueltos en las consultas
    boolean nuevoRegistro; // PAra controlar si se va a insertar un nuevo registro
    
    public ConectaClientes() 
    {
        conn = null; 
        sentenciaSQL = null; 
        rs = null; 
        nuevoRegistro = false;
    }
    
    // Método para registrar el driver, abrir y conectar con la base de datos
    public void conecta() throws SQLException 
    {
        String jdbcUrl=null;
        
        try {
            //Registramos el Driver de MySQL
            String driver = "com.mysql.cj.jdbc.Driver";
            Class.forName(driver).newInstance();
            System.out.println("Driver "+ driver +" Registrado correctamente");
            
            //Abrimos la conexión con la Base de Datos
            System.out.println("Conectando con la Base de datos...");
            jdbcUrl = "jdbc:mysql://localhost:3306/tienda"; // Dirección donde se ubica la base de datos tienda
            
            //Si da excepción sobre el "time zone" comentad la línea anterior y usad la siguiente:
            //jdbcUrl = "jdbc:mysql://localhost:3306/tienda?serverTimezone=UTC"; 
            
            // Conectamos con la base de datos usando la dirección, el usuario y la contraseña (por defecto usuario "root" contraseña ""
            conn = DriverManager.getConnection(jdbcUrl,"root",""); 
            
            System.out.println("Conexión establecida con la Base de datos...");
        } 
        catch(SQLException se) 
        {
            //Errores de JDBC
            se.printStackTrace();
        } 
        catch(Exception e) 
        {
            //Errores de Class.forName
            e.printStackTrace();
        }
    }
    
    // Método para preparar la sentencia a enviar las consultas
    public void crearSentencia() throws java.sql.SQLException
    {
        // Crear una sentencia para enviar consultas a la base de datos
        sentenciaSQL = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
        
        System.out.println("\nSentencia creada con éxito.");
    }
    
    // Método para cerrar la conexión de la base de datos
    public void cerrarConexion() throws java.sql.SQLException
    {
        // Cerramos la conexión con la BBDD
        if (rs != null) 
            rs.close();
        if (sentenciaSQL != null) 
            sentenciaSQL.close();
        if (conn != null) 
            conn.close();
        
        System.out.println("\nConexión cerrada con éxito.");
    }
    
    // Método para ejecutar la sentencia sql pasada por parámetro
    public void ejecutaSQL(String sql) throws java.sql.SQLException
    {
        // Realizamos la consulta y obtenemos los resultados
        rs = sentenciaSQL.executeQuery(sql);
    }
    
    // Métodos para obtener los diferentes registros de la tabla
    
    public void irAlFinal() throws java.sql.SQLException
    {
        try 
        {
            rs.last(); // Obtenemos el último registro
        } 
        catch (Exception e ) 
        {
            e.printStackTrace();
        }
    }
    
    public void irAlSiguiente() throws java.sql.SQLException
    {
        try 
        {
            rs.next(); // Obtenemos el siguiente registro
        } 
        catch (Exception e ) 
        {
            e.printStackTrace();
        }
    }
    
    public void irAlAnterior() throws java.sql.SQLException
    {
        try 
        {
            rs.previous(); // Obtenemos el registro anterior
        } 
        catch (Exception e ) 
        {
            e.printStackTrace();
        }
    }
    public void irAlPrimero() throws java.sql.SQLException{
        try 
        {
            rs.first(); // Obtenemos el primer registro
        }
        catch (Exception e) 
        {
            e.printStackTrace();
        }
    }
    
    // Método para insertar un nuevo registro
    public void nuevo() throws java.sql.SQLException
    {
        nuevoRegistro = true;
        
        try 
        {
            rs.moveToInsertRow(); // Nos preparamos para insertar el nuevo registro
        }
        catch (Exception e) 
        {
            e.printStackTrace();
        }
    }
    
    // Método para aceptar la operación a realizar (Insertar o editar)
    public void aceptar(String nomb, String direc) throws java.sql.SQLException
    {
        // Rellenamos los valores a insertar
        rs.updateString("nombre", nomb);
        rs.updateString("direccion", direc);
        
        if (nuevoRegistro) {
            rs.insertRow(); // Insertamos el registro
            rs.last(); // Nos vamos al final de todos los registros
        }
        else
            rs.updateRow(); // Si la variable nuevoRegistro es false actualizamos el registro
    }

    // Método para borrar el registro seleccionado
    public void borrar() throws java.sql.SQLException
    {
        rs.deleteRow(); // Borramos el registro
        rs.last(); // Nos vamos al final de todos los registros
    }
    
    // Método para cancelar la acción (Inertar o Editar)
    public void cancela() throws java.sql.SQLException
    {
        rs.cancelRowUpdates(); // Cancelamos la operación
    }
        
}
