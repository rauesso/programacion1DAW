/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1;

import java.util.Scanner;

/**
 *
 * Ejercicio 1: Programa que divide dos números y captura las excepciones generadas
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n1, n2, div;
        boolean error;
        
        // creamos un bucle para volver a pedir los números en caso de que salten las excepciones
        do
        {
            try
            {
                error = false;
                
                System.out.print("Introduce el primer número: ");
                n1 = Integer.parseInt(in.nextLine()); // porque el enunciado nos pide que se introduzcan los valores como String

                System.out.print("Introduce el segundo número: ");
                n2 = Integer.parseInt(in.nextLine());

                div = n1 / n2;

                System.out.println("La división es " + div);
            }
            catch(NumberFormatException e)
            {
               System.out.println("Error al introducir el número. Vuelve a introducir los números."); 
               error = true;
            }
            catch(ArithmeticException e)
            {
                System.out.println("Error al dividir entre 0. Vuelve a introducir los números."); 
                error = true;
            }
        }
        while(error);
    }
    
}
