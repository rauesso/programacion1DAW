/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2;

import java.util.Scanner;
import java.util.InputMismatchException;

/**
 *
 * Ejercicio 2: Programa que suma dos vectores y captura las excepciones generadas
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[] v1 = new int[5];
        int[] v2 = new int[5];
        int[] v3;
        
        // En este ejercicio lanzamos las excepciones desde los métodos y las tratamos en el main.
        // Si ocurre una excepción, el programa muestra un mensaje de error y finaliza.
       try
       {
            System.out.println("Introduce el primer vector:");
            llenarVector(v1);

            System.out.println("Introduce el segundo vector:");
            llenarVector(v2);

            v3 = sumarVectoresIguales(v1, v2);

            System.out.println("El vector suma es:");
            mostrarVector(v3);
        }
        catch(ArrayIndexOutOfBoundsException e)
        {
            System.out.println("Error: se han sobrepasado los límites del vector.");
        }
        catch (InputMismatchException e){//La excepción InputMismatchException es lanzada por la clase Scanner cuando el elemento recibido no corresponde al tipo de dato esperado.
            System.out.println("Error: el elemento recibido no corresponde al tipo de dato esperado.");
        }
    }
     
    // Método que llena un vector por teclado
    static void llenarVector(int[] v) // No hace falta escribir 'throws ArrayIndexOutOfBoundsException...' en el prototipo de la función pq se trata de una excepción conocida por java.
    {
        try //Estos try/catch podrían eliminarse, ya que al tener un bloque try/catch en el main, desde donde se llama al método, se capturaría desde allí la excepción y se trataría.
            // No obstante, hemos optado por dejarlos pensando en el principio de reutilización del código de java, ya que si desde otra clase (sin try-catch) se llamara a este método
            // y devolviera un error, este se perdería y no sería tratado.
        {
            Scanner in = new Scanner(System.in);
            int i;

            for(i = 0; i < v.length; i++)
            {
                System.out.print("Introduce el elemento " + i + ": ");
                v[i] = in.nextInt();
            }
        }
        catch(ArrayIndexOutOfBoundsException e)
        {
            // Al lanzar la excepción del catch no hace falta escribir 'throws ArrayIndexOutOfBoundsException' en el prototipo de la función.
            throw e; 
        }
        catch (InputMismatchException e){
            throw e;
        }
    }
    
    // Método que devuleve el vector suma de dos vectores iguales
    static int[] sumarVectoresIguales(int[] v, int[] v2) throws ArrayIndexOutOfBoundsException, InputMismatchException //Aunque como hemos indicado en la función anterior, no es necesario, aquí os lo indicamos para que veais cómo se especificaría más de una excepción
    {
        try
        {
            int[] v3 = new int[v.length];
            int i;

            for(i = 0; i < v.length; i++)
                v3[i] = v[i] + v2[i];

            return v3;
        }
        catch(ArrayIndexOutOfBoundsException e)
        {
            throw e;
        }
        catch (InputMismatchException e){
            throw e;
        }
    }
    
    // Método que muestra un vector
    static void mostrarVector(int[] v)
    {
        try
        {
            int i;

            System.out.print("[ ");

            for(i = 0; i < v.length; i++)
                System.out.print(v[i] + " ");

            System.out.print("]");
        }
        catch(ArrayIndexOutOfBoundsException e)
        {
            throw e;
        }
        catch (InputMismatchException e){
            throw e;
        }
    }
}
