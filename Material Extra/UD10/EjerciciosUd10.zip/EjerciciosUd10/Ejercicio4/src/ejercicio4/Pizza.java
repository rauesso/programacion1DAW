/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio4;

// clase pizza con los atributos de la misma
public class Pizza {
    private String nombre;
    private int cantidad;
    private boolean extra;
    private int extra1;
    private int extra2;
    private int extra3;
    
    Pizza()
    {
        this.nombre = null;
        this.cantidad = 0;
        this.extra = false;
        this.extra1 = 0;
        this.extra2 = 0;
        this.extra3 = 0;
    }
    
    // Constructor si no hay ingredientes extra
    Pizza(String nom, int cant, boolean extra)
    {
        this.nombre = nom;
        this.cantidad = cant;
        this.extra = extra;
        this.extra1 = 0;
        this.extra2 = 0;
        this.extra3 = 0;
    }
    // Constructor si hay ingredientes extra
    Pizza(String nom, int cant, boolean extra, int extra1, int extra2, int extra3)
    {
        this.nombre = nom;
        this.cantidad = cant;
        this.extra = extra;
        this.extra1 = extra1;
        this.extra2 = extra2;
        this.extra3 = extra3;
    }

    public void mostrar()
    {
        System.out.println("Los datos de la pizza son: ");
        System.out.println("\tNombre: " + this.nombre);
        System.out.println("\tCantidad: " + this.cantidad);
        
        if(this.extra)
        {
           System.out.println("\tLleva ingredientes extra:");
           System.out.println("\t\tCantidad del ingrediente1: " + this.extra1);
           System.out.println("\t\tCantidad del ingrediente2: " + this.extra2);
           System.out.println("\t\tCantidad del ingrediente3: " + this.extra3);
        }
        else
            System.out.println("No lleva ingredientes extra");
        
    }
        
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public boolean isExtra() {
        return extra;
    }

    public void setExtra(boolean extra) {
        this.extra = extra;
    }

    public int getExtra1() {
        return extra1;
    }

    public void setExtra1(int extra1) {
        this.extra1 = extra1;
    }

    public int getExtra2() {
        return extra2;
    }

    public void setExtra2(int extra2) {
        this.extra2 = extra2;
    }

    public int getExtra3() {
        return extra3;
    }

    public void setExtra3(int extra3) {
        this.extra3 = extra3;
    }
    
}
