/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio4;

// Clase cliente con los atributos del mismo
public class Cliente {
    private String nombre;
    private String apellidos;
    private String dni;
    
    Cliente()
    {
        this.nombre = null;
        this.apellidos = null;
        this.dni = null;
    }
    
    Cliente(String nom, String ape, String dni)
    {
        this.nombre = nom;
        this.apellidos = ape;
        this.dni = dni;
    }

    public void mostrar()
    {
        System.out.println("Los datos del cliente son: ");
        System.out.println("\tNombre: " + this.nombre);
        System.out.println("\tApellidos: " + this.apellidos);
        System.out.println("\tDni: " + this.dni);
    }
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }
    
    
}
