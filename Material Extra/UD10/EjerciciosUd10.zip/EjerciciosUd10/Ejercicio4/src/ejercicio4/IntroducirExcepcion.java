/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio4;

// Excepcion creada para los datos introducidos de la pizza
public class IntroducirExcepcion extends Exception{
    private int num;
    private String desc;
    
    IntroducirExcepcion(int num, String desc)
    {
        this.num = num;
        this.desc = desc;
    }
    
    public String toString()
    {
        return "Excepcion: Introducido " + this.num + "." + this.desc;
    }
}
