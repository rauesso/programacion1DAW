/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio4;

// Excepción para la comprobación del DNI
public class DniExcepcion extends Exception{
    private String dni;
    
    DniExcepcion(String dni)
    {
        this.dni = dni;
    }
    
    public String toString()
    {
        return "Excepción: El dni " + this.dni + " es incorrecto.";
    }
}
