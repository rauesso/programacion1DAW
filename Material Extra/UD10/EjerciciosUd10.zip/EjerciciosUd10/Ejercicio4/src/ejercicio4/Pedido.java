/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio4;

import java.util.ArrayList;

// clase pedido con los datos del clientes y las pizzas a pedir
public class Pedido {
    private Cliente cliente;
    private Pizza pizza;
    
    Pedido()
    {
        this.cliente = new Cliente();
        this.pizza = new Pizza();
    }
    
    Pedido(Cliente c, Pizza p)
    {
        this.cliente = c;
        this.pizza = p;
    }

    public void mostrar()
    {
        this.cliente.mostrar();
        this.pizza.mostrar();
    }
    
    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Pizza getPizza() {
        return pizza;
    }

    public void setPizza(Pizza pizza) {
        this.pizza = pizza;
    }
    
}
