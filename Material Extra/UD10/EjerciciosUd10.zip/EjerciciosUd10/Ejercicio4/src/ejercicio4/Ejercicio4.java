/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio4;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author USUARIO
 */
public class Ejercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        boolean error;
        String nom, ape, dni;
        int tipo, cant;
        Pizza pizza;
        Cliente cliente;
        Pedido pedido;
        
        do
        {
            try
            {
                error = false;
                
                System.out.println("FORMULARIO PARA REALIZAR EL PEDIDO");
                System.out.println("Introduce los datos del cliente:");
 
                cliente = introducirCliente();
                
                System.out.println("Introduce los datos de la pizza:");
                
                pizza = introducirPizza();
                
                pedido = new Pedido(cliente, pizza);
                
                System.out.println("El pedido realizado es: ");
                
                pedido.mostrar();
                
            }
            catch(DniExcepcion | IntroducirExcepcion | InputMismatchException e) // Cuando los catch contienen el mismo trozo de código se puede escribir así.
            {
                System.out.println(e);
                System.out.println("Realiza otro pedido.");
                error = true;
            }
            
        }while(error);
    }
    
    static Cliente introducirCliente() throws DniExcepcion
    {
        Scanner in = new Scanner(System.in);
        String nom, ape, dni;
        Cliente c;
        
        System.out.print("Nombre: ");
        nom = in.nextLine();

        System.out.print("Apellidos: ");
        ape = in.nextLine();

        System.out.print("DNI: ");
        dni = in.nextLine();

        comprobarDni(dni); // Si el dni es incorrecto lanzamos la excepción.
        
        c = new Cliente(nom, ape, dni);
        
        return c;
    }
    
    static void comprobarDni(String dni) throws DniExcepcion
    {
        boolean val = true;
        int indice=0, i;
        char letra;
        long num;
        String letras = "TRWAGMYFPDXBNJZSQVHLCKET";

        // comprobamos que nif son todo números, excepto la última posición
        for(i = 0; i <= (dni.length() - 2); i++)
        {
            if(Character.isLetter(dni.charAt(i)))
            {
                throw new DniExcepcion(dni);
            }
        }

        // y que letra es una letra.
        if(Character.isDigit(dni.charAt(dni.length()-1)))
        {
            throw new DniExcepcion(dni);
        }
        if(val) //si es true, significa que no había letras en la primera parte del nif, y que el último char no era un dígito
        {
            num = Long.parseLong(dni.substring(0,(dni.length()-1))); //nos quedamos con los dígitos, e.d. quitamos la letra final
            dni = dni.toUpperCase(); //pasamos a mayúsculas
            letra = dni.charAt(dni.length()-1); //nos quedamos con la letra
            indice = (int) (num % 23); //el resto de dividir el número por 23, nos dará el índice a la letra correspondiente
            
            if(letra != letras.charAt(indice))
            {
                throw new DniExcepcion(dni);
            }
        }
    }
    
    static Pizza introducirPizza() throws IntroducirExcepcion
    {
        Scanner in = new Scanner(System.in);
        int tipo, cant, extra, ex1, ex2, ex3;
        String nombre = "";
        Pizza pizza;
        
        try
        {
            System.out.print("Tipo (1-Provenzal, 2-Barbacoa, 3-Mediterránea): ");
            tipo = in.nextInt();

            // Comprobamos si el tipo introducido es correcto
            if(tipo < 1 || tipo > 3)
                throw new IntroducirExcepcion(tipo, "El tipo de pizza no existe.");

            switch(tipo)
            {
                case 1:
                    nombre = "Provenzal";
                break;
                case 2:
                    nombre = "Barbacoa";
                break;
                case 3:
                    nombre = "Mediterránea";
                break;
            }

            System.out.print("Cantidad (entre 1 y 10): ");
            cant = in.nextInt();

            // Comprobamos si la cantidad introducida en correcta
            if(cant < 1 || cant > 10)
                throw new IntroducirExcepcion(tipo, "Cantidad incorrecta.");

            System.out.print("Extras (0-No, 1-Sí): ");
            extra = in.nextInt();

            // Comprobamos si el número introducido es 0 ó 1
            if(extra < 0 || extra > 1)
                throw new IntroducirExcepcion(extra, "Número de extra incorrecto.");

            if(extra == 1)
            {
                // Comprobamos todas las cantidades de los ingredientes extra
                
                System.out.print("Cantidad ingradiente extra1 (entre 1 y 5): ");
                ex1 = in.nextInt();

                if(ex1 < 1 || ex1 > 5)
                    throw new IntroducirExcepcion(tipo, "Cantidad ingrediente extra1 incorrecta.");

                System.out.print("Cantidad ingradiente extra2 (entre 1 y 5): ");
                ex2 = in.nextInt();

                if(ex2 < 1 || ex2 > 5)
                    throw new IntroducirExcepcion(tipo, "Cantidad ingrediente extra2 incorrecta.");

                System.out.print("Cantidad ingradiente extra1 (entre 1 y 5): ");
                ex3 = in.nextInt();

                if(ex3 < 1 || ex3 > 5)
                    throw new IntroducirExcepcion(tipo, "Cantidad ingrediente extra3 incorrecta.");

                pizza = new Pizza(nombre, cant, true, ex1, ex2, ex3); // si hay ingradientes extra
            }
            else
                pizza = new Pizza(nombre, cant, false); // Si no hay ingradientes extra

            return pizza;
        }
        catch(InputMismatchException e) // Exccepción lanzada por Scanner al intentar leer un entero y encontrar una letra.
        {
            throw e;
        }
    }
}
