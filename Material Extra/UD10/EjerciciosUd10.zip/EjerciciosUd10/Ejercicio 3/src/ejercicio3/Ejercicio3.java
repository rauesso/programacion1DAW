/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio3;

import java.util.Scanner;

/**
 *
 * Ejercicio 3: Programa que lanza una excepción si dos números son negativos.
 */
public class Ejercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n1, n2;
        
        // Si queremos volver a pedir los números utilizaríamos un bucle como en el ejercicio 1.
        try
        {
            System.out.print("Introduce el primer número: ");
            n1 = Integer.parseInt(in.nextLine());

            System.out.print("Introduce el segundo número: ");
            n2 = Integer.parseInt(in.nextLine());
            
            comprobarNegativos(n1, n2);
            
            System.out.println("Alguno de los números es positivo.");
            
        }
        catch(NumberFormatException e)
        {
            System.out.println("Error al introducir el número. Vuelve a introducir los números.");
        }
        catch(NumerosNegativosExcepcion e)
        {
            System.out.println(e);
        }
    }
    
    // Método que lanza una excepción si los dos números son negativos
    static void comprobarNegativos(int n1, int n2) throws NumerosNegativosExcepcion
    {
        if(n1 < 0 && n2 < 0)
            throw new NumerosNegativosExcepcion(n1, n2);
    }
}
