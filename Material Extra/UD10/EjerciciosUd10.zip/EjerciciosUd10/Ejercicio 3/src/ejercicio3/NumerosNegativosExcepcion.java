package ejercicio3;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

// Creamos nuestra propia excepción
public class NumerosNegativosExcepcion extends Exception{
    private int n1;
    private int n2;
    
    NumerosNegativosExcepcion(int n1, int n2)
    {
        this.n1 = n1;
        this.n2 = n2;
    }
    
    // Sobreescribimos el método toString de la clase madre para mostrar el mensaje.
    public String toString()
    {
        return "Excepción: Los números " + this.n1 + " y " + this.n2 + " son negativos.";
    }
    
}
