/*
 3. Realiza un programa que debe ir pidiendo números al usuario hasta que el usuario introduzca el cero.
Para cada numero introducido, hay que decir si es primo o no. Hay que recordar que un numero es primo si solo es divisible
por si mismo y por 1. La clase tendrá un atributo (el número), un constructor, 2 métodos para actualizar y recuperar el valor
del atributo y un último método que nos dirá si es primo o no (boolean).
 */
package ejercicio3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Ejercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // declaración de variables
        BufferedReader stdin = new BufferedReader (new InputStreamReader(System.in));
        String teclado;
        Primo primo;
        int valor=0;

        do
        {

            System.out.print("Introduce el numero a comprobar (cero para terminar): ");
            teclado = stdin.readLine();

            valor = Integer.parseInt(teclado);

            if(valor != 0)
            {
                primo = new Primo(valor);

                if(primo.esPrimo())
                    System.out.println("El número es primo.");
                else
                    System.out.println("El número no es primo.");
            }

        } while (valor != 0);
    
    }
    
}
