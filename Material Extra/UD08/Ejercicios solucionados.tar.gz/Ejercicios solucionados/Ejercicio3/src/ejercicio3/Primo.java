/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio3;


public class Primo {
    //En esta clase, al igual que la anterior solo tendremos un atributo, un número entero para calcular si es primo o no. 
    //También será privado.
    
    // Atributo
    private int num;
    
    //Métodos
    //Crearemos un constructor con parámetros para darle valor al atributo.
    
    //Constructor
    public Primo(int n)
    {
        num = n;
    }

    //Crearemos los métodos set y get para establecer y obtener el valor del atributo.
    public int getNum() 
    {
        return num;
    }

    public void setNum(int num) 
    {
        this.num = num;
    }
    
    //Y por último el método para devolver si el atributo es un número primo o no.
    public boolean esPrimo()
    {
        boolean primo = true;
        int cont, div;

        for(cont=2; cont <= this.num/2; cont++)
        {
            div = this.num % cont;

            if(div == 0) 
                primo = false;

        }
        
        if(((!primo) || (this.num == 1)) || (this.num==2))
            primo = false;
        else
            primo = true;
        
        return primo;
    }
}
