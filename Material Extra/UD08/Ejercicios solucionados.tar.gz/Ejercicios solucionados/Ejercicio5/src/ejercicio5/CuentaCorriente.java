/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio5;

//En este ejercicio crearemos una clase con dos atributos: número y saldo. Los dos privados.
public class CuentaCorriente 
{
    // Atributos
    private int numero;
    private float saldo;
    
    // Métodos
    /*
    Crearemos un constructor con parámetros donde sólo le pasaremos el número de cuenta ya que, como dice el enunciado,
    el saldo inicialmente debe ser 0. Por eso asignaremos el valor pasado como parámetro al atributo con el número de cuenta
    y el saldo lo inicializaremos a 0.
    */
    // Constructor
    public CuentaCorriente (int numero)
    {
        // Al llamarse las variables igual el "this" es necesario
        this.numero = numero;
        this.saldo = 0;
    }
    
    /*
    Crearemos dos métodos, uno para ingresar (sumaremos la cantidad al saldo) y otro para hacer el reintegro
    (restaremos la cantidad al saldo).
    */
    void ingresar(float ingresa) 
    {
        this.saldo = this.getSaldo() + ingresa;
    }

    void reintegro(float reintegro) 
    {
        this.saldo = this.getSaldo() - reintegro;
    }
    
    /*
    Crearemos los métodos de get y set para el número de cuenta y solo el get para el saldo, ya que no tiene sentido
    que modifiquemos el saldo sin hacer una imposición o reintegro.
    */
    public int getNumero() 
    {
        return numero;
    }

    public void setNumero(int numero) 
    {
        this.numero = numero;
    }

    public float getSaldo() 
    {
        return saldo;
    }
    
}
