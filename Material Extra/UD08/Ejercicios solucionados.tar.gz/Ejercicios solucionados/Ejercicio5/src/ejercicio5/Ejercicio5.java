/*
5. Se desea llevar un control del estado de una cuenta corriente; la cuenta corriente está caracterizada por número de cuenta
y su saldo, sobre ella se pueden realizar tres tipos de operaciones:
    saldo: devuelve el saldo de la cuenta (puede ser negativo).
    imposición (cantidad): ingresa en la cuenta una cantidad de dinero.
    reintegro (cantidad): saca de la cuenta una determinada cantidad de dinero.

Supondremos que la cuenta inicialmente tiene un saldo de cero. Escribe una clase CuentaCorriente que implemente la funcionalidad
descrita.
 */
package ejercicio5;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Ejercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)throws IOException {
        BufferedReader stdin = new BufferedReader (new InputStreamReader(System.in));
        int teclado, ingreso, reintegro;
        
        System.out.print("Introduce el número de cuenta: ");
        teclado = Integer.parseInt(stdin.readLine());
        
        CuentaCorriente cc = new CuentaCorriente(teclado);
        
        // Ingresamos x €
        System.out.print("Introduce el valor del ingreso en cuenta: ");
        ingreso=Integer.parseInt(stdin.readLine());
        cc.ingresar(ingreso);
        
        // Hacemos un reintegro de 25€
        System.out.print("Introduce el valor del reintegro: ");
        reintegro=Integer.parseInt(stdin.readLine());
        cc.reintegro(reintegro);
        
        System.out.println("El estado de la cuenta " + cc.getNumero() + " es de " + cc.getSaldo() + " €.");
    }
    
}
