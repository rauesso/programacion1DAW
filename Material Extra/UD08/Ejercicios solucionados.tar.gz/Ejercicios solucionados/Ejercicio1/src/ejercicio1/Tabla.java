/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Como dice el ejercicio, la clase debe tener dos atributos: 
 * num_tabla(número de la tabla a calcular) y num_mult (número de multiplicaciones de la tabla),
 * que serán enteros y los declararemos como privados en la definición de la clase
 * ya que no nos interesa que se acceda a ellos desde fuera de la clase. 
 * Si quisiéramos acceder a ellos desde fuera necesitaríamos crear los métodos get y set asociados.
 */
public class Tabla {
    //Atributos
    private int num_tabla;
    private int num_mult; 
    
    //Métodos
    /**
     * Crearemos un constructor con parámetros para que, a la vez que se crea el objeto, asignar valor a los atributos. 
     * Si quisiéramos crear un constructor sin parámetros deberíamos inicializar en su interior los atributos a un valor por defecto. 
     * Si hacemos esto desde el programa principal deberemos crear el objeto y posteriormente rellenar los atributos utilizando
     * los métodos set.
     */
    
    //Constructor
    
    public Tabla (int n_tabla, int n_mult)
    {
        num_tabla = n_tabla;
        num_mult = n_mult;
    }
 
    // Mostrar la tabla de multiplicar
    /**
     * En el método que muestra la tabla de multiplicar simplemente se muestran las multiplicaciones utilizando los valores
     * de ambos atributos.
     */
    
    public void mostrarTabla() 
    {
        int i = 0;
        System.out.println("TABLA DEL "+ num_tabla +".");
        System.out.println("=========================");
        for (i = 1; i <= num_mult; i++)
                {
                    System.out.println(num_tabla+" x " + i + " = " + (num_tabla * i));
                }
    }
    
    
     /**
      * En el método de preguntaTabla, en esta propuesta de solución, se preguntan todas las multiplicaciones de la tabla, 
      * indicando si la respuesta del usuario es correcta o no.
      */
    
    
    public void preguntaTabla() throws IOException
    {
        BufferedReader stdin = new BufferedReader (new InputStreamReader(System.in));
        String teclado;
        int i =0;
        int valor =0;

        System.out.println("Tabla del " + num_tabla);
        for (i = 1; i <= num_mult; i++)
        {

            System.out.print("¿Cuanto es " + num_tabla +" x " + i + "? : ");
            teclado = stdin.readLine();

            valor = Integer.parseInt(teclado);

            System.out.print("[" + num_tabla + " x " + i + " = "+(num_tabla * i) + "]");

        if (valor == (num_tabla * i))
                System.out.println(" CORRECTO!!");
        else
            System.out.println(" ERROR!!");


        }
    }
}
