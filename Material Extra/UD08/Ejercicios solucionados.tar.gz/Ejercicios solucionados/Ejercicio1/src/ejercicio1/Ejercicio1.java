/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1;

import java.io.IOException;
import java.util.Scanner;

public class Ejercicio1 {


    public static void main(String[] args) throws IOException {
        int num, n;
        Scanner in= new Scanner(System.in);
        System.out.print("Introduce el número de la tabla que quieres mostrar: ");
        num=in.nextInt();
        System.out.print("Introduce cuántos números de la tabla del "+ num + " quieres mostrar: ");
        n=in.nextInt();
        Tabla tabla = new Tabla(num,n);
        
        tabla.mostrarTabla();
        
        tabla.preguntaTabla();
    }
    
}
