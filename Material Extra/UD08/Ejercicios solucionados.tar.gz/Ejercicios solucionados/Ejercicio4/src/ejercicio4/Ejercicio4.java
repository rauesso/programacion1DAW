/*
 * 4. Realiza un programa que compruebe el dni junto con la letra. Se tendrá una clase llamada NIF que contendrá un atributo
 * (String), su constructor, un método para actualizar su contenido, un método para recuperar su contenido y método (boolean) 
 * que nos indicará si es correcto o no.
 */
package ejercicio4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Ejercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException{
        //Declaramos las variables
        BufferedReader stdin = new BufferedReader (new InputStreamReader(System.in));
        String teclado;
        
        System.out.print("Introduce el NIF a comprobar: ");
        teclado = stdin.readLine();
        
        Nif n = new Nif(teclado);
        
        if(n.comprobarNif())
            System.out.println("Nif correcto.");
        else
            System.out.println("Nif incorrecto.");
    }
    
}
