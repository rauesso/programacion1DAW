/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio4;

//En esta clase tendremos un atributo privado de tipo String que almacenará el número junto con la letra. 
public class Nif {
    
    // Atributo
    
    private String nif;
    
    // Métodos
    //Crearemos el constructor con parámetros donde asignaremos el valor al atributo. 
    //Constructor
    public Nif (String n)
    {
        nif = n;
    }
    
    //Crearemos los métodos get y set para obtener y establecer el valor al atributo. 
    public String getNif() 
    {
        return nif;
    }

    public void setNif(String nif) 
    {
        this.nif = nif;
    }
    
    /*Y crearemos el método para que devuelva si el nif es correcto. En este método se comprueba primero si la primera parte
    del nif es un número utilizando el método Character.isLetter(char). Posteriormente comprobamos si la última posición del 
    String es una letra utilizando el método Character.isDigit(char)  y si es así obtenemos el módulo 23 del número. 
    En este ejemplo no hacemos uso del gran switch que hacíamos al principio del curso ya que el número obtenido al hacer el
    resto de 23 es justo la posición de la letra del String letras :
    String letras = "TRWAGMYFPDXBNJZSQVHLCKET";
    */
    public boolean comprobarNif()
    {
        boolean val = true;
        int indice=0, i;
        char letra;
        long num;
        String letras = "TRWAGMYFPDXBNJZSQVHLCKET";

        // comprobamos que nif son todo números, excepto la última posición
        for(i = 0; i <= (nif.length() - 2); i++)
        {
            if(Character.isLetter(nif.charAt(i)))
            {
                val = false;
            }
        }

        // y que letra es una letra.
        if(Character.isDigit(nif.charAt(nif.length()-1)))
        {
            val = false;
        }
        if(val) //si es true, significa que no había letras en la primera parte del nif, y que el último char no era un dígito
        {
            num = Long.parseLong(nif.substring(0,(nif.length()-1))); //nos quedamos con los dígitos, e.d. quitamos la letra final
            nif = nif.toUpperCase(); //pasamos a mayúsculas
            letra = nif.charAt(nif.length()-1); //nos quedamos con la letra
            indice = (int) (num % 23); //el resto de dividir el número por 23, nos dará el índice a la letra correspondiente
            val = false;
            if(letra == letras.charAt(indice))
            {
                val=true;
            }
        }
        return(val);

    }
}
