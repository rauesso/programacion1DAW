/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2;


public class Doble {
/*
Esta clase es muy simple. Solo tiene un atributo, un número entero que declararemos privado.
*/
    // Atributo
    private int num;
    
    //Métodos
    /*
    Crearemos el constructor con parámetros para asignar el valor al atributo.
    Al igual que antes, si creamos un constructor sin parámetros, deberíamos inicializar el atributo y en el main deberíamos
    hacer uso del método setValue para darle el valor al atributo.
    */
    
    //Constructor
    public Doble(int n)
    {
        num = n;
    }
    
    //Creamos el método setValue que sirve para cambiar el valor al atributo
    public void setValue(int n)
    {
        num = n;
    }
    
    //y por último con el método getDoble devolvemos el doble del número.
    public float getDouble() 
    {
        return getNum() * 2;
    }

    public int getNum() 
    {
        return num;
    }
}
