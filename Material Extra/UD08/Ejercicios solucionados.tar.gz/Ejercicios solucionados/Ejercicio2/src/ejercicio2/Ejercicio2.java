/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {

        // declaración de variables
        BufferedReader stdin = new BufferedReader (new InputStreamReader(System.in));
        String teclado;
        Doble doble;
        int valor=0;

        // Hasta que entremos cero, pedirá valores y devolverá el doble.
        do
        {

            System.out.println("Introduce el numero a doblar (cero para terminar): ");
            teclado = stdin.readLine();

            valor = Integer.parseInt(teclado);

            // Instanciamos el objeto, ahora que ya conocemos el valor a doblar
            doble = new Doble(valor);

            //Imprimimos el valor original y el doblado obtenido del objeto
            if (doble.getNum()!=0)
                System.out.println("Doble de "+ doble.getNum() + " es: " + doble.getDouble());

        } while (valor != 0);
    }
    
}
