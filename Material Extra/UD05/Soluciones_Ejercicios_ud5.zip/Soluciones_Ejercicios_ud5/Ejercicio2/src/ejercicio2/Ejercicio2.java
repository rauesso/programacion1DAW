/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2;

/**
 *
 * Ejercicio 2: Programa que muestra los números pares comprendidos 
 *              entre el 1 y el 200, sumando de 2 en 2.
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int cont;
        
        for(cont=2;cont<=200;cont=cont+2)
            System.out.print(cont + " ");
        
        System.out.print("\n");
    }
    
}
